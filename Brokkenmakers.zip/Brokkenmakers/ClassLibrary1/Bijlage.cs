﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public class Bijlage
    {
        public string Tittel;
        public string Link;
        public string Wat;
    }
}
