﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public enum Sex { Man, Vrouw}
    public class Persoon
    {
        public string Naam { get; set; }
        public string Voornaam { get; set; }
        public Sex sex { get; set; }
    }
}
