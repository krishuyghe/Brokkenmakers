﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public enum Voertuig { Auto,Vrachtwagen, Camionette}
    public class Materieel 
    {
        public Voertuig Voertuig { get; set; }
        public int nr { get; set; }
        public string schade { get; set; }
    }
}
