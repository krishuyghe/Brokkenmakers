﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public class Report
    {
        public ReportInfo Report_Gegevens;
        public Persoon Rapporteerder;
        public Accident Omschrijving_Acc;
        public Mens Menselijke_schade;
        public Materieel Materiele_schade;
        public Bijlage Bijlage;
    }
}
