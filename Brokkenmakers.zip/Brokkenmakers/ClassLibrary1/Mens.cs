﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public enum Letsel { hoofd, linkerarm, rechterarm }
    
    public class Mens 
    {
        public Persoon Persoon { get; set; }
        public Letsel Letsel { get; set; }
        public string Omschrijving { get; set; }
    }
}
