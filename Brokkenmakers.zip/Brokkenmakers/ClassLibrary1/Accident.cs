﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public class Accident
    {
        public string Omschrijving { get; set; }
    }
}
