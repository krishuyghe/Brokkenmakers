﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARS.Lib
{
    public class ReportInfo
    {
        public DateTime DateOpmaak {get ; set; }
        public DateTime DateOngeluk { get; set; }
        public TimeZone TimeOpmaak { get; set; }
        public TimeZone TimeOngeluk { get; set; }
        public int nummer { get; set; }
     
    }
}
